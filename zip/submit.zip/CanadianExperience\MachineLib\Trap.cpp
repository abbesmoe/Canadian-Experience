/**
 * \file Trap.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "Trap.h"

CTrap::CTrap()
{
}

CTrap::~CTrap()
{
}

void CTrap::Update(double elapsed)
{
}

void CTrap::Draw(Gdiplus::Graphics* graphics)
{
}
