/**
 * \file Motor.cpp
 *
 * \author Moez Abbes
 *
 */

#include "pch.h"
#include "Motor.h"

CMotor::CMotor()
{
}

CMotor::~CMotor()
{
}

void CMotor::Update(double elapsed)
{
}

void CMotor::Draw(Gdiplus::Graphics* graphics)
{
}
