/**
 * \file RotationSource.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "RotationSource.h"

CRotationSource::CRotationSource()
{
}

CRotationSource::~CRotationSource()
{
}
