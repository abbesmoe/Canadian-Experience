/**
 * \file Sink.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "Sink.h"

CSink::CSink()
{
}

CSink::~CSink()
{
}
