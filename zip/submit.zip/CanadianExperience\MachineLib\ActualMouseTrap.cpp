#include "pch.h"
#include "ActualMouseTrap.h"

CActualMouseTrap::CActualMouseTrap()
{
}

CActualMouseTrap::~CActualMouseTrap()
{
}

void CActualMouseTrap::DrawMachine(Gdiplus::Graphics* graphics)
{
}

void CActualMouseTrap::SetLocation(int x, int y)
{
}
