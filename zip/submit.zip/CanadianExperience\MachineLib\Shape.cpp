/**
 * \file Shape.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "Shape.h"

CShape::CShape()
{
}

CShape::~CShape()
{
}

void CShape::Update(double elapsed)
{
}
