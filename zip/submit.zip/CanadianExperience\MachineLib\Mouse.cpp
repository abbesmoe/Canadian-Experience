/**
 * \file Mouse.cpp
 *
 * \author Moez Abbes
 *
 */

#include "pch.h"
#include "Mouse.h"

CMouse::CMouse()
{
}

CMouse::~CMouse()
{
}

bool CMouse::CheckPosition()
{
	return false;
}

void CMouse::Update(double elapsed)
{
}
