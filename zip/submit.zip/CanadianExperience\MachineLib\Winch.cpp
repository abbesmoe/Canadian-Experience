/**
 * \file Winch.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "Winch.h"

CWinch::CWinch()
{
}

CWinch::~CWinch()
{
}

void CWinch::Update(double elapsed)
{
}

void CWinch::Draw(Gdiplus::Graphics* graphics)
{
}
