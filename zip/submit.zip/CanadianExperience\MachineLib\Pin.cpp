/**
 * \file Pin.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "Pin.h"

CPin::CPin()
{
}

CPin::~CPin()
{
}

void CPin::Update(double elapsed)
{
}
