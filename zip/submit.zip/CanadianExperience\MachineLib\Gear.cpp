/**
 * \file Gear.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "Gear.h"

CGear::CGear()
{
}

CGear::~CGear()
{
}

void CGear::Update(double elapsed)
{
}

void CGear::Draw(Gdiplus::Graphics* graphics)
{
}
