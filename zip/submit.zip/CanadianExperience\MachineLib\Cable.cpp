/**
 * \file Cable.cpp
 *
 * \author Moez Abbes
 */
#include "pch.h"
#include "Cable.h"

CCable::CCable()
{
}

CCable::~CCable()
{
}

void CCable::Update(double elapsed)
{
}

void CCable::Draw(Gdiplus::Graphics* graphics)
{
}
